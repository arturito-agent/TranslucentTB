# Synthetic Dynamic resource data

Right/Static: three repetitions, native e4f09c8 candidates and upstream7d baseline.
Executable paths in builds.json are normalized to relative release folders;
measured CSV/GPU values and phase/exit receipts are unchanged. Use Windows QPC
for timing; guest UTC timestamps were not synchronized with the host.

From the source checkout, after extracting this data:

    python3 Tests/dynamic/compare.py /path/to/data/Right-Static --dwm-observer /path/to/data/dwm-right-static.csv

This is one of nine required position/workload combinations; the full first
version remains in progress. Process GPU memory is reported separately from
private commit; shared GPU allocations must not be added as physical totals.
